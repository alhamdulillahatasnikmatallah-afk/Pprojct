import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cend_dolphin/ui/term_widgets.dart';
import 'package:cend_dolphin/core/sound.dart';

class NetToolsScreen extends StatelessWidget {
  const NetToolsScreen({super.key});
  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'NET',
        child: ListView(children: [
          TermListTile(
              label: 'Ping (HTTP)',
              icon: Icons.network_ping,
              onTap: () => _go(context, const _PingScreen())),
          TermListTile(
              label: 'Cek DNS domain',
              icon: Icons.dns,
              onTap: () => _go(context, const _DnsScreen())),
          TermListTile(
              label: 'Cek IP publik',
              icon: Icons.public,
              onTap: () => _go(context, const _PublicIpScreen())),
          TermListTile(
              label: 'Tes kecepatan',
              icon: Icons.speed,
              onTap: () => _go(context, const _SpeedTestScreen())),
        ]),
      );
  void _go(BuildContext c, Widget p) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => p));
}

class _PingScreen extends StatefulWidget {
  const _PingScreen();
  @override
  State<_PingScreen> createState() => _PingScreenState();
}

class _PingScreenState extends State<_PingScreen> {
  final host = TextEditingController(text: 'google.com');
  String out = '';
  bool loading = false;

  Future<void> _ping() async {
    Sfx.i.click();
    setState(() {
      loading = true;
      out = 'Mengirim permintaan...';
    });
    try {
      var h = host.text.trim();
      if (!h.contains('://')) h = 'https://$h';
      final sw = Stopwatch()..start();
      final r = await http.head(Uri.parse(h)).timeout(const Duration(seconds: 8));
      sw.stop();
      out = 'Status: ${r.statusCode}\nWaktu: ${sw.elapsedMilliseconds} ms\n'
          '(Catatan: ini HTTP HEAD, bukan ICMP ping.)';
    } catch (e) {
      Sfx.i.error();
      out = 'Gagal: tidak ada respons / tidak ada internet.';
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'PING (HTTP)',
        child: ListView(children: [
          TermField(controller: host, hint: 'contoh: google.com'),
          const SizedBox(height: 10),
          TermButton(label: loading ? 'MENGIRIM...' : 'PING', onTap: loading ? () {} : _ping),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _DnsScreen extends StatefulWidget {
  const _DnsScreen();
  @override
  State<_DnsScreen> createState() => _DnsScreenState();
}

class _DnsScreenState extends State<_DnsScreen> {
  final host = TextEditingController(text: 'google.com');
  String out = '';
  bool loading = false;

  Future<void> _lookup() async {
    Sfx.i.click();
    setState(() {
      loading = true;
      out = 'Mencari...';
    });
    try {
      final addrs = await InternetAddress.lookup(host.text.trim());
      out = addrs.map((a) => '${a.type.name}: ${a.address}').join('\n');
      if (out.isEmpty) out = 'Tidak ditemukan.';
    } catch (e) {
      Sfx.i.error();
      out = 'Gagal: domain tidak ditemukan atau tidak ada internet.';
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'CEK DNS',
        child: ListView(children: [
          TermField(controller: host, hint: 'contoh: google.com'),
          const SizedBox(height: 10),
          TermButton(label: loading ? 'MENCARI...' : 'LOOKUP', onTap: loading ? () {} : _lookup),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _PublicIpScreen extends StatefulWidget {
  const _PublicIpScreen();
  @override
  State<_PublicIpScreen> createState() => _PublicIpScreenState();
}

class _PublicIpScreenState extends State<_PublicIpScreen> {
  String out = '';
  bool loading = false;

  Future<void> _check() async {
    Sfx.i.click();
    setState(() {
      loading = true;
      out = 'Mengecek...';
    });
    try {
      final r = await http
          .get(Uri.parse('https://api.ipify.org?format=text'))
          .timeout(const Duration(seconds: 8));
      out = 'IP publik HP ini: ${r.body}';
    } catch (_) {
      try {
        final r2 = await http
            .get(Uri.parse('https://icanhazip.com'))
            .timeout(const Duration(seconds: 8));
        out = 'IP publik HP ini: ${r2.body.trim()}';
      } catch (e) {
        Sfx.i.error();
        out = 'Gagal: tidak ada internet.';
      }
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'CEK IP PUBLIK',
        child: ListView(children: [
          TermButton(label: loading ? 'MENGECEK...' : 'CEK IP SAYA', onTap: loading ? () {} : _check),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _SpeedTestScreen extends StatefulWidget {
  const _SpeedTestScreen();
  @override
  State<_SpeedTestScreen> createState() => _SpeedTestScreenState();
}

class _SpeedTestScreenState extends State<_SpeedTestScreen> {
  String out = '';
  bool loading = false;

  Future<void> _test() async {
    Sfx.i.click();
    setState(() {
      loading = true;
      out = 'Mengunduh data uji (maks 5 MB)...';
    });
    try {
      final sw = Stopwatch()..start();
      // File uji publik kecil (~5 MB) dari layanan yang umum dipakai.
      final r = await http
          .get(Uri.parse('https://speed.hetzner.de/5MB.bin'))
          .timeout(const Duration(seconds: 20));
      sw.stop();
      final bytes = r.bodyBytes.length;
      final seconds = sw.elapsedMilliseconds / 1000.0;
      final mbps = (bytes * 8 / 1000000) / seconds;
      out = 'Unduhan: ${(bytes / 1000000).toStringAsFixed(2)} MB\n'
          'Waktu: ${seconds.toStringAsFixed(2)} s\n'
          'Kecepatan: ${mbps.toStringAsFixed(2)} Mbps\n'
          '(Perkiraan kasar, bukan pengukuran resmi.)';
    } catch (e) {
      Sfx.i.error();
      out = 'Gagal: tidak ada internet atau koneksi lambat.';
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'TES KECEPATAN',
        child: ListView(children: [
          Text('Akan mengunduh hingga 5 MB data. Pastikan tidak memakai kuota terbatas.',
              style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 11)),
          const SizedBox(height: 10),
          TermButton(label: loading ? 'MENGUJI...' : 'MULAI TES', onTap: loading ? () {} : _test),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}
