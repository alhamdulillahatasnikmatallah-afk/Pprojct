import 'dart:math';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cend_dolphin/ui/term_widgets.dart';
import 'package:cend_dolphin/core/sound.dart';

class PrivacyToolsScreen extends StatelessWidget {
  const PrivacyToolsScreen({super.key});
  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'PRIVASI',
        child: ListView(children: [
          TermListTile(
              label: 'Cek kekuatan password',
              icon: Icons.lock,
              onTap: () => _go(context, const _PasswordStrengthScreen())),
          TermListTile(
              label: 'Cek kebocoran email (situs resmi)',
              icon: Icons.email,
              onTap: () => _openBreachSite(context)),
        ]),
      );

  void _go(BuildContext c, Widget p) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => p));

  void _openBreachSite(BuildContext context) async {
    Sfx.i.click();
    final uri = Uri.parse('https://haveibeenpwned.com');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Tidak bisa membuka link.')));
      }
    }
  }
}

class _PasswordStrengthScreen extends StatefulWidget {
  const _PasswordStrengthScreen();
  @override
  State<_PasswordStrengthScreen> createState() => _PasswordStrengthScreenState();
}

class _PasswordStrengthScreenState extends State<_PasswordStrengthScreen> {
  final ctrl = TextEditingController();
  String out = '';

  void _check() {
    Sfx.i.click();
    final pw = ctrl.text;
    if (pw.isEmpty) {
      setState(() => out = 'Masukkan password dulu.');
      return;
    }
    int pool = 0;
    if (RegExp(r'[a-z]').hasMatch(pw)) pool += 26;
    if (RegExp(r'[A-Z]').hasMatch(pw)) pool += 26;
    if (RegExp(r'[0-9]').hasMatch(pw)) pool += 10;
    if (RegExp(r'[^a-zA-Z0-9]').hasMatch(pw)) pool += 32;
    if (pool == 0) pool = 1;
    final entropy = pw.length * (log(pool) / log(2));
    final guesses = pow(2, entropy);
    final seconds = guesses / 1e10; // asumsi 10 miliar coba/detik
    String label;
    if (entropy < 28) {
      label = 'SANGAT LEMAH';
    } else if (entropy < 36) {
      label = 'LEMAH';
    } else if (entropy < 60) {
      label = 'SEDANG';
    } else if (entropy < 80) {
      label = 'KUAT';
    } else {
      label = 'SANGAT KUAT';
    }
    out = 'Kekuatan: $label\n'
        'Panjang: ${pw.length} karakter\n'
        'Estimasi waktu tebak (kasar): ${_fmtTime(seconds)}\n\n'
        'Saran: gunakan minimal 12 karakter, campur huruf besar/kecil,\n'
        'angka, dan simbol. Hindari kata umum atau data pribadi.\n\n'
        '(Dihitung sepenuhnya di HP ini, tidak dikirim ke mana pun.)';
    setState(() {});
  }

  String _fmtTime(double s) {
    if (s < 1) return 'kurang dari 1 detik';
    if (s < 60) return '${s.toStringAsFixed(0)} detik';
    if (s < 3600) return '${(s / 60).toStringAsFixed(0)} menit';
    if (s < 86400) return '${(s / 3600).toStringAsFixed(0)} jam';
    if (s < 31536000) return '${(s / 86400).toStringAsFixed(0)} hari';
    return '${(s / 31536000).toStringAsFixed(0)} tahun';
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'KEKUATAN PASSWORD',
        child: ListView(children: [
          TermField(controller: ctrl, hint: 'Ketik password untuk dicek...'),
          const SizedBox(height: 10),
          TermButton(label: 'CEK', onTap: _check),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}
