import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:cend_dolphin/ui/term_widgets.dart';
import 'package:cend_dolphin/core/theme.dart';
import 'package:cend_dolphin/core/sound.dart';

class EncodeToolsScreen extends StatelessWidget {
  const EncodeToolsScreen({super.key});
  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'ENCODE',
        child: ListView(children: [
          TermListTile(
              label: 'Base64 / URL encode',
              icon: Icons.transform,
              onTap: () => _go(context, const _TextEncodeScreen())),
          TermListTile(
              label: 'Hash teks (MD5/SHA1/SHA256)',
              icon: Icons.fingerprint,
              onTap: () => _go(context, const _HashScreen())),
          TermListTile(
              label: 'Konverter biner/hex/desimal',
              icon: Icons.pin,
              onTap: () => _go(context, const _NumBaseScreen())),
          TermListTile(
              label: 'Generator password',
              icon: Icons.password,
              onTap: () => _go(context, const _PasswordGenScreen())),
          TermListTile(
              label: 'Generator QR',
              icon: Icons.qr_code,
              onTap: () => _go(context, const _QrGenScreen())),
          TermListTile(
              label: 'Scanner QR',
              icon: Icons.qr_code_scanner,
              onTap: () => _go(context, const _QrScanScreen())),
        ]),
      );
  void _go(BuildContext c, Widget p) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => p));
}

class _TextEncodeScreen extends StatefulWidget {
  const _TextEncodeScreen();
  @override
  State<_TextEncodeScreen> createState() => _TextEncodeScreenState();
}

class _TextEncodeScreenState extends State<_TextEncodeScreen> {
  final input = TextEditingController();
  String out = '';
  void _run(String mode) {
    Sfx.i.click();
    try {
      switch (mode) {
        case 'b64e':
          out = base64Encode(utf8.encode(input.text));
          break;
        case 'b64d':
          out = utf8.decode(base64Decode(input.text));
          break;
        case 'urle':
          out = Uri.encodeFull(input.text);
          break;
        case 'urld':
          out = Uri.decodeFull(input.text);
          break;
      }
      setState(() {});
    } catch (e) {
      Sfx.i.error();
      setState(() => out = 'Error: format input tidak valid.');
    }
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'BASE64 / URL',
        child: ListView(children: [
          TermField(controller: input, hint: 'Masukkan teks...'),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TermButton(label: 'B64 ENCODE', onTap: () => _run('b64e'))),
            const SizedBox(width: 8),
            Expanded(child: TermButton(label: 'B64 DECODE', onTap: () => _run('b64d'))),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TermButton(label: 'URL ENCODE', onTap: () => _run('urle'))),
            const SizedBox(width: 8),
            Expanded(child: TermButton(label: 'URL DECODE', onTap: () => _run('urld'))),
          ]),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _HashScreen extends StatefulWidget {
  const _HashScreen();
  @override
  State<_HashScreen> createState() => _HashScreenState();
}

class _HashScreenState extends State<_HashScreen> {
  final input = TextEditingController();
  String out = '';
  void _run() {
    Sfx.i.click();
    final bytes = utf8.encode(input.text);
    out = 'MD5:    ${md5.convert(bytes)}\n'
        'SHA1:   ${sha1.convert(bytes)}\n'
        'SHA256: ${sha256.convert(bytes)}';
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'HASH TEKS',
        child: ListView(children: [
          TermField(controller: input, hint: 'Masukkan teks...'),
          const SizedBox(height: 10),
          TermButton(label: 'HASH', onTap: _run),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _NumBaseScreen extends StatefulWidget {
  const _NumBaseScreen();
  @override
  State<_NumBaseScreen> createState() => _NumBaseScreenState();
}

class _NumBaseScreenState extends State<_NumBaseScreen> {
  final input = TextEditingController();
  String out = '';
  void _run() {
    Sfx.i.click();
    try {
      final n = int.parse(input.text.trim());
      out = 'Biner:   ${n.toRadixString(2)}\n'
          'Oktal:   ${n.toRadixString(8)}\n'
          'Hex:     ${n.toRadixString(16)}\n'
          'Desimal: $n';
    } catch (_) {
      out = 'Masukkan angka desimal yang valid.';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'KONVERTER ANGKA',
        child: ListView(children: [
          TermField(controller: input, hint: 'Masukkan angka desimal...', type: TextInputType.number),
          const SizedBox(height: 10),
          TermButton(label: 'KONVERSI', onTap: _run),
          const SizedBox(height: 14),
          TermOutput(text: out),
        ]),
      );
}

class _PasswordGenScreen extends StatefulWidget {
  const _PasswordGenScreen();
  @override
  State<_PasswordGenScreen> createState() => _PasswordGenScreenState();
}

class _PasswordGenScreenState extends State<_PasswordGenScreen> {
  double length = 16;
  bool upper = true, lower = true, digits = true, symbols = true;
  String out = '';

  void _gen() {
    Sfx.i.click();
    const u = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const l = 'abcdefghijklmnopqrstuvwxyz';
    const d = '0123456789';
    const sym = '!@#\$%^&*()-_=+';
    String pool = '';
    if (upper) pool += u;
    if (lower) pool += l;
    if (digits) pool += d;
    if (symbols) pool += sym;
    if (pool.isEmpty) {
      setState(() => out = 'Pilih minimal satu jenis karakter.');
      return;
    }
    final rnd = Random.secure();
    out = List.generate(length.round(), (_) => pool[rnd.nextInt(pool.length)]).join();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'GENERATOR PASSWORD',
        child: ListView(children: [
          Text('Panjang: ${length.round()}', style: termText(12, TermPalette.text)),
          Slider(
              value: length,
              min: 8,
              max: 64,
              divisions: 56,
              activeColor: TermPalette.accent,
              onChanged: (v) => setState(() => length = v)),
          CheckboxListTile(
              value: upper,
              onChanged: (v) => setState(() => upper = v ?? true),
              title: Text('Huruf besar', style: termText(12, TermPalette.text)),
              activeColor: TermPalette.accent),
          CheckboxListTile(
              value: lower,
              onChanged: (v) => setState(() => lower = v ?? true),
              title: Text('Huruf kecil', style: termText(12, TermPalette.text)),
              activeColor: TermPalette.accent),
          CheckboxListTile(
              value: digits,
              onChanged: (v) => setState(() => digits = v ?? true),
              title: Text('Angka', style: termText(12, TermPalette.text)),
              activeColor: TermPalette.accent),
          CheckboxListTile(
              value: symbols,
              onChanged: (v) => setState(() => symbols = v ?? true),
              title: Text('Simbol', style: termText(12, TermPalette.text)),
              activeColor: TermPalette.accent),
          const SizedBox(height: 8),
          TermButton(label: 'GENERATE', onTap: _gen),
          const SizedBox(height: 14),
          TermOutput(text: out),
          if (out.isNotEmpty && !out.startsWith('Pilih'))
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: TermButton(
                  label: 'SALIN',
                  onTap: () => Clipboard.setData(ClipboardData(text: out))),
            ),
        ]),
      );
}

class _QrGenScreen extends StatefulWidget {
  const _QrGenScreen();
  @override
  State<_QrGenScreen> createState() => _QrGenScreenState();
}

class _QrGenScreenState extends State<_QrGenScreen> {
  final input = TextEditingController();
  String data = '';
  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'GENERATOR QR',
        child: ListView(children: [
          TermField(controller: input, hint: 'Teks atau link...'),
          const SizedBox(height: 10),
          TermButton(label: 'BUAT QR', onTap: () {
            Sfx.i.click();
            setState(() => data = input.text);
          }),
          const SizedBox(height: 16),
          if (data.isNotEmpty)
            Center(
              child: Container(
                padding: const EdgeInsets.all(12),
                color: Colors.white,
                child: QrImageView(data: data, size: 200),
              ),
            ),
        ]),
      );
}

class _QrScanScreen extends StatefulWidget {
  const _QrScanScreen();
  @override
  State<_QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<_QrScanScreen> {
  String result = '';
  @override
  Widget build(BuildContext context) => TermScaffold(
        title: 'SCANNER QR',
        child: Column(children: [
          SizedBox(
            height: 300,
            child: MobileScanner(
              onDetect: (capture) {
                final codes = capture.barcodes;
                if (codes.isNotEmpty && codes.first.rawValue != null) {
                  Sfx.i.happy();
                  setState(() => result = codes.first.rawValue!);
                }
              },
            ),
          ),
          const SizedBox(height: 14),
          TermOutput(text: result.isEmpty ? 'Arahkan kamera ke QR...' : result),
        ]),
      );
}
