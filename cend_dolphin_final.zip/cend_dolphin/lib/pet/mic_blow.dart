import 'dart:async';
import 'package:permission_handler/permission_handler.dart';

/// Deteksi tiup mic dinonaktifkan sementara (noise_meter conflict dengan
/// Flutter Gradle plugin terbaru). API tetap sama biar pemanggil nggak rusak.
class MicBlowDetector {
  final void Function() onBlow;
  MicBlowDetector(this.onBlow);

  bool running = false;

  Future<bool> start() async {
    try {
      final status = await Permission.microphone.request();
      if (!status.isGranted) return false;
      // Placeholder: fitur tiup mic dimatikan agar build sukses.
      running = true;
      return true;
    } catch (_) {
      running = false;
      return false;
    }
  }

  void stop() {
    running = false;
  }
}
