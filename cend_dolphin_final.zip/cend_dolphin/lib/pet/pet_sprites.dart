import 'package:flutter/material.dart';
import 'package:cend_dolphin/pet/pet_model.dart';

/// Ekspresi wajah pet, dipakai saat idle & reaksi interaksi.
enum Expr {
  normal,
  blink,
  sleepy,
  sleep,
  bored,
  sad,
  laugh,
  shock,
  angry,
  love,
  dizzy,
}

/// Palet warna per jenis pet (badan utama, badan gelap, aksen, pipi).
class PetPalette {
  final Color body, bodyDark, accent, cheek, outline;
  const PetPalette(
      {required this.body,
      required this.bodyDark,
      required this.accent,
      required this.cheek,
      required this.outline});
}

const Map<PetKind, PetPalette> petPalettes = {
  PetKind.dolphin: PetPalette(
      body: Color(0xFFF7B37A),
      bodyDark: Color(0xFFE89A58),
      accent: Color(0xFFFFFFFF),
      cheek: Color(0xFFFFC9C9),
      outline: Color(0xFF6B4B33)),
  PetKind.cat: PetPalette(
      body: Color(0xFFFFFFFF),
      bodyDark: Color(0xFFE6E6E6),
      accent: Color(0xFFF4B6C2),
      cheek: Color(0xFFFFC9C9),
      outline: Color(0xFF444444)),
  PetKind.dog: PetPalette(
      body: Color(0xFFCB9A6E),
      bodyDark: Color(0xFFA97A50),
      accent: Color(0xFFFFFFFF),
      cheek: Color(0xFFFFC9C9),
      outline: Color(0xFF5B4330)),
  PetKind.rabbit: PetPalette(
      body: Color(0xFFFFFFFF),
      bodyDark: Color(0xFFE9E9E9),
      accent: Color(0xFFF4B6C2),
      cheek: Color(0xFFFFC9C9),
      outline: Color(0xFF888888)),
  PetKind.fox: PetPalette(
      body: Color(0xFFF2A765),
      bodyDark: Color(0xFFD98A47),
      accent: Color(0xFFFFFFFF),
      cheek: Color(0xFFFFC9C9),
      outline: Color(0xFF6B4423)),
  PetKind.dragon: PetPalette(
      body: Color(0xFFC9BCE0),
      bodyDark: Color(0xFFA996CC),
      accent: Color(0xFFE8DCF5),
      cheek: Color(0xFFFFC9C9),
      outline: Color(0xFF5B4B73)),
};

/// Bentuk dasar badan (16x16) per pet. 'B'=body, 'D'=bodyDark, 'A'=accent,
/// 'C'=cheek, 'K'=outline, '.'=transparan. Baris mata/mulut (indeks 6-10)
/// ditimpa sesuai ekspresi lewat [applyExpr].
const Map<PetKind, List<String>> _base = {
  PetKind.dolphin: [
    '................',
    '.....KKKKKK.....',
    '....KBBBBBBK....',
    '...KBBBBBBBBK...',
    '..KBBBBBBBBBBK..',
    '.KBBBBBBBBBBBBK.',
    'KBBB..EE..EEBBBK',
    'KBBB..EE..EEBBBK',
    'KBBBBBBBBBBBBBBK',
    'KBBBB..MM..BBBBK',
    '.KBBBBBBBBBBBBK.',
    '..KDDBBBBBBDDK..',
    '...KDD....DDK...',
    '....KD....DK....',
    '.....K....K.....',
    '................',
  ],
  PetKind.cat: [
    '....K......K....',
    '...KBK....KBK...',
    '..KBBBK..KBBBK..',
    '.KBBBBBKKBBBBBK.',
    'KBBBBBBBBBBBBBBK',
    'KBBBCBBBBBBBCBBK',
    'KBB..EE..EE..BBK',
    'KBB..EE..EE..BBK',
    'KBBBBBB..BBBBBBK',
    'KBBBB..MM..BBBBK',
    '.KBBBBBBBBBBBBK.',
    '..KBBBBBBBBBBK..',
    '...KBBBBBBBBK...',
    '....KBBBBBBK....',
    '.....KBBBBK.....',
    '................',
  ],
  PetKind.dog: [
    '.KK............K',
    'KBBK..........KD',
    'KBBBK........KDD',
    '.KBBBK......KDDK',
    '..KBBBBBBBBBBK..',
    '.KBBBBBBBBBBBBK.',
    'KBBBCBB..BBBCBBK',
    'KBB..EE..EE..BBK',
    'KBB..EE..EE..BBK',
    'KBBBBBB..BBBBBBK',
    'KBBBB.MMMM.BBBBK',
    '.KBBBBBBBBBBBBK.',
    '..KBBBBBBBBBBK..',
    '...KBBBBBBBBK...',
    '....KBBBBBBK....',
    '................',
  ],
  PetKind.rabbit: [
    '...K......K.....',
    '..KAK....KAK....',
    '..KAK....KAK....',
    '..KAK....KAK....',
    '..KBK....KBK....',
    '...KBBBBBBK.....',
    '..KBBBBBBBBK....',
    '.KBBBCBBBCBBK...',
    '.KBB..EE..EEK...',
    '.KBB..EE..EEK...',
    '.KBBBBBB..BBK...',
    '.KBBBB.MM.BBK...',
    '..KBBBBBBBBK....',
    '...KBBBBBBK.....',
    '....KBBBBK......',
    '................',
  ],
  PetKind.fox: [
    'KK............KK',
    'KDK..........KDK',
    'KDDK........KDDK',
    '.KDBK......KBDK.',
    '..KBBBBBBBBBBK..',
    '.KBBBBBBBBBBBBK.',
    'KBBBCBB..BBBCBBK',
    'KBB..EE..EE..BBK',
    'KBB..EE..EE..BBK',
    'KBBBBBB..BBBBBBK',
    'KBBBB.MMMM.ABBBK',
    '.KBBBBBBBBBBBBK.',
    '..KBBBBBBBBBBK..',
    '...KAAAAAAAAK...',
    '....KAAAAAAK....',
    '................',
  ],
  PetKind.dragon: [
    '..K..K....K..K..',
    '.KDK.KD....DK.DK',
    '..KBBBBBBBBBBK..',
    '.KBBBBBBBBBBBBK.',
    'KBBBBBBBBBBBBBBK',
    'KBBBCBB..BBBCBBK',
    'KBB..EE..EE..BBK',
    'KBB..EE..EE..BBK',
    'KBBBBBB..BBBBBBK',
    'KBBBB.MMMM.BBBBK',
    '.KBBBBBBBBBBBBK.',
    '..KBBAABBAABBK..',
    '...KBBBBBBBBK...',
    '....KBBBBBBK....',
    '.....KBBBBK.....',
    '................',
  ],
};

/// Baris pengganti (indeks 6-9 area mata & mulut) per ekspresi.
/// Setiap entri: {rowIndex: stringBaruPanjang16}. Posisi 'E' tetap mata,
/// 'M' mulut; kita cukup ganti sebagian karakter memakai templat sederhana.
List<String> applyExpr(List<String> base, Expr e) {
  final rows = List<String>.from(base);
  String eyes(String style) {
    switch (style) {
      case 'blink':
        return rows[6].replaceAll('EE', '--');
      case 'closed':
        return rows[6].replaceAll('EE', '^^');
      case 'shock':
        return rows[6].replaceAll('EE', 'OO');
      case 'angry':
        return rows[6].replaceAll('EE', '>>');
      case 'love':
        return rows[6].replaceAll('EE', '<3').replaceAll('EE', '<3');
      case 'dizzy':
        return rows[6].replaceAll('EE', '@@');
      default:
        return rows[6];
    }
  }

  switch (e) {
    case Expr.normal:
      break;
    case Expr.blink:
      rows[6] = eyes('blink');
      rows[7] = eyes('blink');
      break;
    case Expr.sleepy:
      rows[6] = eyes('blink');
      break;
    case Expr.sleep:
      rows[6] = eyes('closed');
      rows[7] = eyes('closed');
      break;
    case Expr.bored:
      rows[6] = eyes('blink');
      break;
    case Expr.sad:
      rows[6] = eyes('blink');
      break;
    case Expr.laugh:
      rows[6] = eyes('closed');
      rows[7] = eyes('closed');
      break;
    case Expr.shock:
      rows[6] = eyes('shock');
      rows[7] = eyes('shock');
      break;
    case Expr.angry:
      rows[6] = eyes('angry');
      rows[7] = eyes('angry');
      break;
    case Expr.love:
      rows[6] = eyes('closed');
      rows[7] = eyes('closed');
      break;
    case Expr.dizzy:
      rows[6] = eyes('dizzy');
      rows[7] = eyes('dizzy');
      break;
  }
  return rows;
}

Map<String, Color> paletteFor(PetKind k) {
  final p = petPalettes[k]!;
  return {
    'K': p.outline,
    'B': p.body,
    'D': p.bodyDark,
    'A': p.accent,
    'C': p.cheek,
    'E': const Color(0xFF3A2E28),
    'M': const Color(0xFF3A2E28),
    '.': Colors.transparent,
  };
}

List<String> spriteFor(PetKind k, Expr e) => applyExpr(_base[k]!, e);
