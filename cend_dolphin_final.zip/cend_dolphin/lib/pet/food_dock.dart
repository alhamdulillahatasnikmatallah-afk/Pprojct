import 'package:flutter/material.dart';
import 'package:cend_dolphin/core/theme.dart';

class FoodItem {
  final String id, label, emoji;
  const FoodItem(this.id, this.label, this.emoji);
}

const foods = [
  FoodItem('apel', 'Apel', '🍎'),
  FoodItem('pisang', 'Pisang', '🍌'),
  FoodItem('anggur', 'Anggur', '🍇'),
  FoodItem('stroberi', 'Stroberi', '🍓'),
  FoodItem('jeruk', 'Jeruk', '🍊'),
  FoodItem('semangka', 'Semangka', '🍉'),
  FoodItem('ikan', 'Ikan', '🐟'),
  FoodItem('daging', 'Daging', '🍖'),
  FoodItem('wortel', 'Wortel', '🥕'),
];

class FoodDock extends StatelessWidget {
  final void Function(FoodItem) onFeed;
  const FoodDock({super.key, required this.onFeed});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 86,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          itemCount: foods.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final f = foods[i];
            return Draggable<FoodItem>(
              data: f,
              feedback: _chip(f, dragging: true),
              childWhenDragging: Opacity(opacity: 0.3, child: _chip(f)),
              child: GestureDetector(
                onTap: () => onFeed(f),
                child: _chip(f),
              ),
            );
          },
        ),
      );

  Widget _chip(FoodItem f, {bool dragging = false}) => Container(
        width: 64,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: dragging
              ? [const BoxShadow(color: Colors.black26, blurRadius: 8)]
              : const [BoxShadow(color: Colors.black12, blurRadius: 3, offset: Offset(0, 2))],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(f.emoji, style: const TextStyle(fontSize: 26)),
          const SizedBox(height: 2),
          Text(f.label, style: roundedText(9, PastelPalette.brown)),
        ]),
      );
}
